export const environment = {
  firebase: {
    projectId: 'webfejl-9449e',
    appId: '1:405372540078:web:26b295f19bd5bf5cfd093f',
    storageBucket: 'webfejl-9449e.appspot.com',
    apiKey: 'AIzaSyCkYa70Nrvzmes6j8cI4ABhZwha63vVOJc',
    authDomain: 'webfejl-9449e.firebaseapp.com',
    messagingSenderId: '405372540078',
    measurementId: 'G-GVXJ37VV3L',
  },};
